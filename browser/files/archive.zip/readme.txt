BT-TEST-ARCHIVE
Made-up archive for the browser test page.
